//
//  ContentView.swift
//  Takehome W02_Heidy Mudita Sutedjo
//
//  Heidy Mudita Sutedjo - 0706022310044
//

import SwiftUI

struct Task: Identifiable {
    let id = UUID()
    var title: String
    var isCompleted: Bool = false
}

struct ContentView: View {
    @State private var tasks: [Task] = [
            Task(title: "Takehome Mobcomp"),
            Task(title: "ISSG AFL-1"),
            Task(title: "Rundown Event 2025"),
            Task(title: "Siram Tanaman"),
            Task(title: "Kasih Makan Kucing"),
            Task(title: "Meal Prep")
        ]
    
    @State private var newTask: String = ""
    
    var progress: Double {
        guard !tasks.isEmpty else { return 0 }
        let completed = tasks.filter { $0.isCompleted }.count
        return Double(completed) / Double(tasks.count)
    }
    
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    Text("Progress: \(Int(progress * 100))%")
                        .font(.headline)
                    
                    ProgressView(value: progress)
                        .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                        .padding(.horizontal)
                }
                .padding(.vertical)
                
                HStack {
                    TextField("Add new task", text: $newTask)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Button(action: {
                        if !newTask.isEmpty {
                            tasks.append(Task(title: newTask))
                            newTask = ""
                        }
                    }) {
                        Image(systemName: "plus.circle.fill")
                    }
                }
                
                List {
                    ForEach(tasks.indices, id: \.self) { index in
                        HStack {
                            Image(systemName: tasks[index].isCompleted ? "checkmark.circle.fill" : "circle")
                                .foregroundColor(tasks[index].isCompleted ? .green : .gray)
                                .onTapGesture {
                                    tasks[index].isCompleted.toggle()
                                }
                            Text(tasks[index].title)
                                .strikethrough(tasks[index].isCompleted, color: .black)
                                .foregroundColor(tasks[index].isCompleted ? .gray : .primary)
                        }
                    }
                }
            }
            .navigationTitle(Text("📝To Do List"))
            
        }
        .padding()
    }
}
    
#Preview {
    ContentView()
}
