//
//  Takehome_W02_Heidy_Mudita_SutedjoApp.swift
//  Takehome W02_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 22/09/25.
//

import SwiftUI

@main
struct Takehome_W02_Heidy_Mudita_SutedjoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
