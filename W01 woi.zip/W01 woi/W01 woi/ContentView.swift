//
//  ContentView.swift
//  W01 woi
//
//  Created by student on 11/09/25.
//

import SwiftUI

struct Student { //struct itu class
    var name: String
    var year: Int
    func display() -> String //gabisa declare
    {
        "\(name), \(year)"
    }
}

enum UserStatus {case offline, online, busy}

struct ContentView: View {
    let userName = "blabla" //declare variable diluar body
    let scores = [89, 92, 76]
    let student = Student(name: "Bibi", year: 2)
    let status: UserStatus = .online
    
    var badge: String{
        scores.allSatisfy{$0 >= 86} ? "✅" : "❌"
    }
    var body: some View {
        VStack (spacing: 10){
            Text("Hello, \(userName)")
                .font(.title)
            
            Text("Student: \(student.display())")
            
            Text("Status: \(status == .online ? "💚Online" : "❤️Offline")")
            
            Text("Badge: \(badge)")
//            HStack{
//                Image("heidy")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 300, height: 200)
//                    .clipShape(Circle())
//                    .shadow(color: .blue, radius: 20)
//                    .padding(.vertical, 50)
//            }
//            
//            HStack{
//                Text("Hi! I'm Heidy")
//                    .font(.system(size:30))
//                    .foregroundStyle(.blue)
//                    .fontWeight(.bold)
//                    .padding(.vertical, 5)
//            }
//            
//            HStack{
//                Text("My age is 20")
//                    .font(.system(size:30))
//                    .foregroundStyle(.blue)
//                    .padding(.vertical, 5)
//            }
//            
//            HStack{
//                Text("🐼🦭🤍")
//                    .font(.system(size:50))
//                    .padding(.vertical, 5)
//            }
//            Text("Hello World!")
//                .font(.largeTitle)
//                .fontWeight(.bold)      //Modifier
//                .padding(.horizontal)
//            
//            Text("Declarative UI")
//                .font(.headline)
//            
//            Text("🦊")
//                .font(.system(size: 150))
//                .padding()
//                .overlay(content:{
//                    Circle().strokeBorder(.gray
//                        .opacity(0.3), lineWidth: 2)
//                }
//                         )
            
//            Image(systemName: "sparkles") //SF Symbols
//                .imageScale(.large)
//                .foregroundStyle(.pink)
//                .font(.system(size:100))
//                .padding()
//                .overlay(content:{
//                    Circle().strokeBorder(.gray
//                        .opacity(0.3), lineWidth: 2)
//                }
//                         )
        }
        .padding()
    }
    let name = "Alice" //Variabel let tidak bisa diubah
    var age = 20 //Variabel var bisa diubah-ubah
    func greet(){
        print("hello, \(name), age \(age)")
    }
}

#Preview {
    ContentView()
}
