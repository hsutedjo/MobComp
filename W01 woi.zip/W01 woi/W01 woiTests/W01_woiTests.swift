//
//  W01_woiTests.swift
//  W01 woiTests
//
//  Created by student on 11/09/25.
//

import Testing
@testable import W01_woi

struct W01_woiTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
