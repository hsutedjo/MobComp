//
//  MovieGridView.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieGridView: View {
    let movies: [Movie]
    @Binding var searchBar: String
    
    let columns = [
        GridItem(.adaptive(minimum: 160), spacing: 16)
    ]
    
    //buat yang kefilter search bar
    var filtered: [Movie] {
        if searchBar.isEmpty {
            return movies
        }
        else {
            return movies.filter { $0.title.lowercased().contains(searchBar.lowercased()) }
        }
    }
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 16) {
                ForEach(filtered) { movie in
                    NavigationLink(destination: MovieDetailView(movie: movie)) {
                        MovieCard(movie: movie)
                    }
                }
            }
            .padding()
        }
    }
}
