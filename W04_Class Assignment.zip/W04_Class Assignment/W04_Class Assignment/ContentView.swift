//
//  ContentView.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct ContentView: View {
    @State private var searchBar: String = ""
    @StateObject private var store = MovieStore()
    
    var body: some View {
        NavigationStack {
            VStack {
                TextField("🔍Search movies...", text: $searchBar)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding()
                
                MovieGridView(movies: store.movies, searchBar: $searchBar)
            }
                .navigationTitle("🎬 UCFlix")
        }
    }
}


#Preview {
    ContentView()
}
