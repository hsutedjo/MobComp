//
//  MovieDetailView.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI


struct MovieDetailView: View {
    let movie: Movie
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                AsyncImage(url: movie.posters) { phase in
                    if let image = phase.image {
                        image
                            .resizable()
                            .scaledToFit()
                    } else if phase.error != nil {
                        Color.red
                    } else {
                        ProgressView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: 300)
                .cornerRadius(12)
                .shadow(radius: 5)
                
                Text(movie.title)
                    .font(.title)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                
                Text(movie.genre)
                    .font(.headline)
                    .foregroundColor(.secondary)
                                
                Text(movie.desc)
                    .font(.body)
                    .padding()
            }
            .padding()
        }
        .navigationTitle(movie.title)
        .navigationBarTitleDisplayMode(.inline)
    }
}


#Preview {
    MovieDetailView(
        movie: Movie(
            posters: URL(string:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt-DVZ5AP8H-EnoydYzdBu3nH3gUOgasrNPg&s")!,
            title: "One Battle After Another",
            genre: "Action Epic",
            desc: "When their evil enemy resurfaces after 16 years, a group of ex-revolutionaries reunite to rescue one of their own's daughter."        )
    )
}
