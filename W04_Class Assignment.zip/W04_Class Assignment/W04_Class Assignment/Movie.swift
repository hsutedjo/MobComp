//
//  Movie.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI

struct Movie: Identifiable {
    let id = UUID()
    let posters: URL
    let title: String
    let genre: String
    let desc: String
    }
