//
//  MovieStore.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//

import SwiftUI
import Combine

class MovieStore: ObservableObject {
    @Published var movies: [Movie] = [
        Movie(posters: URL(string:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt-DVZ5AP8H-EnoydYzdBu3nH3gUOgasrNPg&s")!, title: "One Battle After Another", genre: "Action Epic", desc: "When their evil enemy resurfaces after 16 years, a group of ex-revolutionaries reunite to rescue one of their own's daughter."),
        Movie(posters: URL(string:"https://m.media-amazon.com/images/M/MV5BZTM0NTQ5ZTktNzIwZS00OWRhLWIxZGEtNTUyMzkzZDVhOTFmXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg")!, title: "Wayward", genre: "Dark Comedy", desc: "A bucolic but sinister town explores the insidious intricacies of the troubled teen industry, and the eternal struggle of the next generation."),
        Movie(posters: URL(string:"https://m.media-amazon.com/images/M/MV5BM2IzZDg0ODYtYWUyZi00YmJmLWE2N2MtMmRmNjAzMWRiYTAzXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg")!, title: "House of Guinness", genre: "Drama, Mystery", desc: "Follows the aftermath of the death of brewery mogul, Sir Benjamin Guinness, and the great impact of his will on the fate of his four adult children: Arthur, Edward, Anne, Ben, and other Dubliners affected by the expanding Guinness empire."),
        Movie(posters: URL(string:"https://m.media-amazon.com/images/M/MV5BOWNmY2YxYzEtMjkzMy00OGE1LTg1MmItOGVjZTFmYWRkMDk5XkEyXkFqcGc@._V1_.jpg")!, title: "Black Rabbit", genre: "Docudrama", desc: "When the owner of a New York City hotspot allows his turbulent brother back in his life, he opens the door to escalating dangers that threaten to bring down everything he's built."),
        Movie(posters: URL(string:"https://m.media-amazon.com/images/M/MV5BOGMwZGJiM2EtMzEwZC00YTYzLWIxNzYtMmJmZWNlZjgxZTMwXkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg")!, title: "Superman", genre: "Action Epic", desc: "Superman must reconcile his alien Kryptonian heritage with his human upbringing as reporter Clark Kent. As the embodiment of truth, justice and the human way he soon finds himself in a world that views these as old-fashioned.")
    ]
}
