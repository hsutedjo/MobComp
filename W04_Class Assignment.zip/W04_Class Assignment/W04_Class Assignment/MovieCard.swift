//
//  MovieCard.swift
//  W04_Class Assignment
//
//  Created by student on 02/10/25.
//
import SwiftUI


struct MovieCard: View {
    let movie: Movie
    
    var body: some View {
        VStack {
            AsyncImage(url: movie.posters) { phase in
                if let image = phase.image {
                    image
                        .resizable()
                        .scaledToFill()
                } else if phase.error != nil {
                    Color.red
                } else {
                    ProgressView()
                }
            }
            .frame(width: 120, height: 180)
            .cornerRadius(8)
            .clipped()
            
            Text(movie.title)
                .font(.headline)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .frame(maxWidth: 120)
            
            Text(movie.genre)
                .font(.subheadline)
                .foregroundColor(.gray)
        }
        .frame(width: 140)
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white)
                .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
        )
    }
}


#Preview {
    MovieCard(
        movie: Movie(
            posters: URL(string:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRt-DVZ5AP8H-EnoydYzdBu3nH3gUOgasrNPg&s")!,
            title: "One Battle After Another",
            genre: "Action Epic",
            desc: "When their evil enemy resurfaces after 16 years, a group of ex-revolutionaries reunite to rescue one of their own's daughter."
        )
    )
}
