//
//  StatsView.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 30/09/25.
//

import SwiftUI

struct StatsView: View {
    var body: some View {
        VStack {
            Text("📊Stats")
                .font(.largeTitle)
        }
    }
}

#Preview {
    StatsView()
}
