//
//  GoalCard.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 30/09/25.
//

import SwiftUI

struct GoalCard: View {
        let columns = [
            GridItem(.flexible()),
            GridItem(.flexible())
        ]

        var body: some View {
            LazyVGrid(columns: columns, spacing: 16) {
                
                // Card 1
                StatCard(icon: "❤️", value: "68 Bpm")
                
                // Card 2
                StatCard(icon: "🔥", value: "0 Kcal")
                
                // Card 3
                StatCard(icon: "⚖️", value: "73 Kg")
                
                // Card 4
                StatCard(icon: "😴", value: "6.2 Hr")
            }
            .padding()
        }
    }

    struct StatCard: View {
        var icon: String
        var value: String
        
        var body: some View {
            VStack {
                HStack(spacing: 12) {
                    Text(icon)
                        .font(.title)
                        .padding(.trailing, 110)
                }
                
                HStack {
                    Text(value)
                        .font(.headline)
                        .padding(.leading, 70)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 80)
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.white)
                    .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
            )
    }
}

#Preview {
    GoalCard()
}
