//
//  LocationView.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 30/09/25.
//

import SwiftUI

struct LocationView: View {
    var body: some View {
        VStack {
            Text("📍Location")
                .font(.largeTitle)
        }
    }
}

#Preview {
    LocationView()
}
