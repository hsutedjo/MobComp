//
//  ContentView.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Heidy Mudita Sutedjo on 30/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            
            LocationView()
                .tabItem {
                    Image(systemName: "mappin.and.ellipse")
                    Text("Location")
                }
            StatsView()
                .tabItem {
                    Image(systemName: "chart.bar.xaxis.ascending")
                    Text("Stats")
                }
            SettingsView()
                .tabItem {
                    Image(systemName: "gearshape.fill")
                    Text("Settings")
            }
        }
    }
}

#Preview {
    ContentView()
}
