//
//  Takehome_W03_Heidy_Mudita_SutedjoApp.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 30/09/25.
//

import SwiftUI

@main
struct Takehome_W03_Heidy_Mudita_SutedjoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
