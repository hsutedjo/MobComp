//
//  HomeView.swift
//  Takehome W03_Heidy Mudita Sutedjo
//
//  Created by Alfred Hans Witono on 30/09/25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack {
            HStack {
                VStack(alignment: .leading) {
                    Text("Good Morning,")
                        .font(.headline)
                        .fontDesign(.serif)
                        .fontWeight(.light)
                    Text("Heidy")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                }
                .padding(.trailing, 140)
                Image("heidy")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 70, height: 70)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .padding(.vertical, 20)
            }
            
            VStack() {
                TextField("🔍Search", text: .constant(""))
                    .padding()
                    .background(Color.white.opacity(0.1))
                    .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 2)
                    .cornerRadius(20)
            }
            .padding(.bottom, 10)
                        
            ZStack {
                RoundedRectangle(cornerRadius: 25)
                    .fill(
                        LinearGradient(
                            gradient: Gradient(colors: [.pink, .purple, .blue]),
                            startPoint: .bottomLeading,
                            endPoint: .topTrailing
                        )
                    )
                    .frame(width: 350, height: 250)
                    .opacity(0.9)

                VStack(spacing: 20) {
                    Text("Today's Goal")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.white)

                    HStack(spacing: 16) {
                        VStack(spacing: 12) {
                            Image(systemName: "figure.run")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)

                            Text("4 Miles")
                                .font(.headline)
                                .foregroundColor(.white)

                            Text("@UC Loop")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .frame(width: 140, height: 120)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(15)

                        // Right Card
                        VStack(spacing: 12) {
                            Image(systemName: "sailboat.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 40, height: 40)
                                .foregroundColor(.white)

                            Text("2 Miles")
                                .font(.headline)
                                .foregroundColor(.white)

                            Text("@Kenjeran Lake")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        .frame(width: 140, height: 120)
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(15)
                    }
                }
            }
            GoalCard()
        }
        .padding(20)
    }
}

#Preview {
    HomeView()
}
