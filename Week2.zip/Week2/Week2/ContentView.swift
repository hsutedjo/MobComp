//
//  ContentView.swift
//  Week2
//
//  Created by student on 18/09/25.
//

import SwiftUI

struct ContentView: View {
    //variable utk toggle
    @State private var isOn: Bool = false
    
    //variable utk Slider
    @State private var volume: Double = 0.5
    
    //utk TextField
    @State private var name: String = ""
    
    //utk actionButton
    @State private var point = 80
    
    //utk List
    let fruits = ["Apple", "Orange", "Banana"]
    
//    private func progressCard(score: Int)
//    -> some View {
//        VStack{
//            Text("Current Score").font(.headline)
//            ProgressView(value: Double(score), total:100)
//            Text("\(score)/100").foregroundStyle(.secondary)
//        }
//        .padding()
//        .background(.green.opacity(0.88))
//        .clipShape(RoundedRectangle(cornerRadius: 20))
//    }
//    
//    private func actionButton(_ title: String, action: @escaping () -> Void) -> some View {
//        Button(title, action: action)
//            .padding(.horizontal, 16).padding(.vertical, 10)
//            .foregroundColor(.white)
//            .background(Color.blue)
//            .cornerRadius(10)
//    }
//    
    var body: some View {
        
        //List
        List(fruits, id: \.self) { fruit in
            HStack {
                Text(fruit)
                Spacer()
                Text("u u a a")
            }
        
        //Action Button
//        VStack{
//            progressCard(score: point)
//            HStack{
//                actionButton("Add 10") { point += 10}
//                actionButton("Reset") { point = 0}
//            }
        
        //Foreach
        //        VStack (spacing: 10) {
        //            //kalau titik" tiga, artinya sampai 10
        //            ForEach(0..<10, id: \.self) { index in
        //                Text("Hello, world!\(index)")
        //            }
        //            Text("Heidy Mudita")
        //            Text("Semarang")
        //            Text("Heidy")
        //            //Spacer menuhin container
        //            Spacer()
        //        }
        
        //ZStack
        
        //        ZStack {
        //            RoundedRectangle(cornerRadius: 20)
        //                .fill(.pink.opacity(0.3))
        //                .frame(width: 200, height: 125)
        //            HStack{
        //                Text("Heidy")
        //                    .foregroundColor(.white)
        //                    .font(.title)
        //                    .frame(width: 100, alignment: .leading)
        //                    .padding(.bottom, 70)
        //                VStack(spacing: 8){
        //                    Text("🐮")
        //                        .font(.title)
        //                        .padding(.top, 30)
        //                    Text("🥭 🫐")
        //                        .font(.title)
        //                }
        //            }
        
        
        //
        //
        //            Circle()
        //                .frame(width: 50, height: 50)
        //                .opacity(0.2)
        
        //Shadow
//        VStack{
//            Text("Shadow Example")
//                .padding()
//                .background(Color.blue)
//                .cornerRadius(10)
//                .shadow(color:.black, radius: 10, x:2, y:2)
//                .opacity(0.88)
//    }
        
        //Object
        VStack{
            
            //Button
//            Button("Tekan Saya") {
//                print("Saya Tertekan")
            }
            
            //Ini manual, not recommended
//            .padding(10)
//            .background(.white)
//            .overlay(RoundedRectangle(cornerRadius: 10)
//                .stroke(.purple, lineWidth: 2))
//            .foregroundColor(.red)
            
            //Udah 1 set
//            .buttonStyle(.bordered)
//            .tint(.pink)
//            
//            Button("Coba Aku"){
//                
//            }
//            .buttonStyle(.bordered)
//            .tint(.green)
//            
            //Image
//            Image(systemName: "star.fill")
            //ini buat ngubah" template warna sesuai sf symbols
//                .symbolRenderingMode(.palette)
//                .font(.system(size: 100))
//                .foregroundColor(.red)
            
            //Toggle
//            Toggle("Enable Notifications", isOn: $isOn)
//                .padding()
            
            //Basically if simple
//            Text( isOn ? "Hore" : "Yahh")
            
            //Slider
//            Slider(value: $volume, in: 0...1)
//            Text("Volume sekarang \(volume)%")
            
            //TextField
//            TextField("Namamu siapa", text: $name)
//                .textFieldStyle(.roundedBorder)
//                .padding()
            
            //normal
//            Text("Hello \(name)!")
            
            //kalau pake if
//            Text(name == "" ? "Hai" : "Hello, \(name)")
        }
    }
}

#Preview {
    ContentView()
}
