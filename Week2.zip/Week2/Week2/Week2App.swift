//
//  Week2App.swift
//  Week2
//
//  Created by student on 18/09/25.
//

import SwiftUI

@main
struct Week2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
