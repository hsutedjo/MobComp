//
//  ContentView.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

//Struct itu immutable
struct ContentView: View {
    //state adalah source of truth
    //    @State private var totalCount = 0
    
    var body: some View{
        //Tabview
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .navigationTitle(Text("Home"))
                .badge("99+")
            
            SearchView()
                .tabItem {
                    Label("Search", systemImage: "magnifyingglass")
                }
        }
        
        .tint(.red)
        
        //Pakai 2 view
        //        VStack{
        //            Text("Parent View")
        //                .font(.largeTitle)
        //            Text("Total Count: \(totalCount)")
        //                .font(.title2)
        //                .padding()
        //
        //            CounterView(count: $totalCount)
        //            Spacer()
        //        }
        //        .padding()
        //        .background(.green.opacity(0.8))
        //    }
    }
}
    
    //State bikin variabel jadi immutable (bisa diubah)
    //    @State private var count = 0
    //    @State private var nama = ""
    //
    //    var body: some View {
    //        VStack {
    //            ContentView2()
    //            Text("Hitung: \(count)")
    //                .font(.largeTitle)
    //            Text("Nama: \(nama)")
    //
    //            TextField("Isi Nama", text: $nama)
    //                .textFieldStyle(RoundedBorderTextFieldStyle())
    //
    //            HStack{
    //                Button("+") {
    //                    count += 1
    //                }
    //
    //                Button("-") {
    //                    count -= 1
    //                }
    //            }
#Preview {
    ContentView()
}
