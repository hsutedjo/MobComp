//
//  ItemScreen.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ItemScreen: View {
    let items = ["🍅Tomato", "🥑Papaya", "🍍Pineapple"]
    
    var body: some View {
        List(items, id: \.self) {
            item in NavigationLink(destination: ItemDetailScreen(item: item)) { Text(item)
            }
        }
//        .navigationDestination(for: String.self) { item in ItemDetailScreen(item: item)
//        }
        .navigationTitle("Items")
    }
}

struct ItemDetailScreen: View {
    let item: String
    
    var body: some View {
        VStack{
            Text("🍍Welcome to Item Detail!🍍")
                .font(.title)
            Text("You selected: \(item)")
        }
        .navigationTitle(item)
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    ItemScreen()
}
