//
//  SearchView.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct SearchView: View {
    var body: some View {
        VStack {
            Text("🔍Search!")
                .font(.largeTitle)
        }
    }
}

#Preview {
    SearchView()
}
