//
//  HomeView.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        VStack {
            NavigationStack{
                VStack {
                    Text("🏡 Home Screen")
                        .font(.largeTitle)
                    
                    NavigationLink("Go to Details") {
                        DetailScreen()
                    }
                    
                    NavigationLink("Show Item") {
                        ItemScreen()
                    }
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
