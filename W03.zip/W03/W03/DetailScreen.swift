//
//  DetailScreen.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct DetailScreen: View {
    var body: some View {
        VStack {
            Text("📝 Detail Screen")
                .font(.largeTitle)
            
            Text("You come from home screen!")
        }
        .navigationBarTitle("Detail")
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    DetailScreen()
}
