//
//  W03App.swift
//  W03
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct W03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
