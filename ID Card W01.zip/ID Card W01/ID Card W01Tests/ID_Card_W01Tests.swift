//
//  ID_Card_W01Tests.swift
//  ID Card W01Tests
//
//  Created by student on 25/09/25.
//

import Testing
@testable import ID_Card_W01

struct ID_Card_W01Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
