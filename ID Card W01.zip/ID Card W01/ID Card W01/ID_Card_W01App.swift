//
//  ID_Card_W01App.swift
//  ID Card W01
//
//  Created by student on 25/09/25.
//

import SwiftUI

@main
struct ID_Card_W01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
