//
//  ContentView.swift
//  ID Card W01
//
//  Created by student on 25/09/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HStack{
            Image("heidy")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 300, height: 200)
                .clipShape(Circle())
                .shadow(color: .blue, radius: 20)
                .padding(.vertical, 50)
        }
        
        HStack{
            Text("Hi! I'm Heidy")
                .font(.system(size:30))
                .foregroundStyle(.blue)
                .fontWeight(.bold)
                .padding(.vertical, 5)
        }
        
        HStack{
            Text("My age is 20")
                .font(.system(size:30))
                .foregroundStyle(.blue)
                .padding(.vertical, 5)
        }
        
        HStack{
            Text("🐼🦭🤍")
                .font(.system(size:50))
                .padding(.vertical, 5)
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
